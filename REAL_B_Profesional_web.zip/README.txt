REAL B PROFESIONÁL s.r.o. – webová stránka

SOUBORY
- index.html: hlavní stránka
- logo.png: logo

JAK SI WEB PROHLÉDNOUT
Otevřete index.html v internetovém prohlížeči. Pro zveřejnění nahrajte oba soubory do webhostingu.

PŘED ZVEŘEJNĚNÍM
Telefon a e-mail jsou již doplněné. Před zveřejněním ještě doplňte konkrétní oblast působení a zkontrolujte všechny texty.
Zkontrolujte všechny texty a rozsah nabízených služeb.

ZVEŘEJNĚNÍ ZDARMA
Lze použít například GitHub Pages. Vytvořte účet, nový repozitář, nahrajte index.html a logo.png a v nastavení Pages povolte publikování. Bez vlastní domény bude adresa ve tvaru uzivatel.github.io/nazev-repozitare. Vlastní doména se kupuje zvlášť a její dostupnost je potřeba ověřit.
